
# Claude: Bootstrap the AI-Agent Company
Create control-plane and agent repos, wire MoE routing, MCP servers (github/ci/deploy/obs/security/vector/secrets/billing), policy-as-code, CI gates (tests/coverage/SAST/DAST/SBOM), ADRs, checklists, KPIs, and rollout issues. Use both closed/open models portfolio and dual-model (maker/critic) review. Demonstrate Issue→PR→Merge→Deploy.
