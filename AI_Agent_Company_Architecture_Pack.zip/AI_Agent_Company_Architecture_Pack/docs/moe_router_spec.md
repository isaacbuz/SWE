
# MoE Router Specification
Scoring = fit*0.35 + reliability*0.2 + cost*0.2 + latency*0.15 + security*0.1
Maker/Critic dual‑model workflow; fallback to open models under budget/outage.
Portfolio includes GPT‑5, Claude 4.x, Gemini 2.5 Pro, Grok 4, Qwen2.5‑Coder‑32B, DeepSeek V3/R1, Llama 3.1 405B, Codestral 25.01, IBM Granite Code.
