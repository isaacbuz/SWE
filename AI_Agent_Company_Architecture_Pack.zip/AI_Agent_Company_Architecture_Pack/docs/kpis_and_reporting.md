
# KPIs
Cycle/lead time, CFR, MTTR, coverage; SAST/DAST trends; SLOs; margin, token$/rev$; policy violations, audit completeness.
