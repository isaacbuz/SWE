
# Rollout Plan
Phase 0: Core router, policy, GitHub MCP. Phase 1: Security/Obs MCP, ADR automation. Phase 2: Multitenancy vectors, client portal. Phase 3: Enterprise (SAML/SCIM, VPC).
