
# Workflows & SOPs
Sales→SOW→Kickoff; Issue→PR→Merge→Deploy with QA/Sec gates; Incident→Postmortem with SRE; ADR updates required for architecture changes.
