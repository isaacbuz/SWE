
# MCP Tooling
Servers: github, ci, deploy, obs, security, vector, secrets, billing, docs.
All access audited; policy maps roles→tools→scopes; per‑tenant namespaces.
