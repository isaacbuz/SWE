
# Policies & Governance
Least privilege; data residency routing; PII redaction; approvals for risky ops; evidence store (ADRs, SBOM, tests, security); SOC2 mapping; immutable audit.
