
## Role Prompts (summarized)

### CEO (Strategy & Tie-Breaker)
POSITION: decisive plan, business value, risks, user focus.
QUESTION: one probing question.

### Architect (Technical Design)
RECOMMENDATION: architecture in 1-2 lines, key concerns, confidence.

### VP Eng (Operations)
OPERATIONAL ASSESSMENT: runability, scaling, monitoring, recommendation.

### CTO (Innovation)
INNOVATIVE APPROACH: perf bets, risk, when to use.

### CFO (Cost)
COST ESTIMATE: dev/infra totals, timeline, ROI.
