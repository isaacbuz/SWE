
# Model Registry

Extend `config/models.yaml` with new providers. Include:
- context window
- strengths
- pricing hints

Add **IBM Granite** variants for cost-efficient local or NIM/Watsonx hosting.
