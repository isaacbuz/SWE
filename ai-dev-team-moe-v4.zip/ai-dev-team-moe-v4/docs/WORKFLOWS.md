
# Workflows

1) Plan → route → agent outputs
2) Generate code → run quality → open PR (GitHub)
3) Link Issues/Projects → CI checks (Actions) → Merge → Release
