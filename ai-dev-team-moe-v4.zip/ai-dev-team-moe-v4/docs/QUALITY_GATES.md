
# Quality Gates

Automate checks after code generation:
- Tests, Linting, Security Scan, Coverage thresholds, Complexity.
Gate must pass before PR is opened or merged.
