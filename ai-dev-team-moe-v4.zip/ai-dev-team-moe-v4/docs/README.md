
# Docs Index
- ARCHITECTURE.md — multi-layer architecture
- MOE_DESIGN.md — mixture-of-experts routing
- MCP_INTEGRATION.md — tool chest via MCP servers
- MODEL_REGISTRY.md — adding/modifying models
- QUALITY_GATES.md — automated verification
- WORKFLOWS.md — end-to-end flows
