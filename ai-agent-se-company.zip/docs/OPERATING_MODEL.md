# Operating Model and Governance

- **Workflow gates:** tests, lint, security, license checks must pass
- **Human approvals:** auth/infra/payment paths require manual review
- **Audit:** every tool call and model selection logged to PR artifacts
