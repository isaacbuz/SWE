# Delivery Roadmap (6 weeks)

- Week 0–1: Contracts, tool adapters, router policy v1
- Week 2–3: Orchestration (Temporal/Prefect), OpenAI planning lane, Claude execution lane
- Week 4: Ops console (Streamlit), Realtime copilot (OpenAI)
- Week 5: Batch maintainer, compliance gate end-to-end
- Week 6: Pilot + tuning, incident swarm playbook
