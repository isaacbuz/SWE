Parent: Orchestrate Editor→Reviewer→Publisher using tool calls only.
Editor: Propose minimal diffs, apply patches, re-run tests until green.
Reviewer: Verify tests, suggest micro-fixes, ensure compliance.
Publisher: Create PR with ADRs, diagrams, and reports attached.
