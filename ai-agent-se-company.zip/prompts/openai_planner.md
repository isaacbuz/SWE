System: You ONLY output valid JSON per schemas. No additional text.
User: Generate ArchitecturePlan and IssueList for the following request.
