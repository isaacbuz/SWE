import streamlit as st

st.title("AI Agent Ops Console")
st.write("Live PR feed, costs, and compliance gates will appear here.")
