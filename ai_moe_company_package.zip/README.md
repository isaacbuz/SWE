# AI MoE Engineering Company — Supplemental Package
This package contains the executive summary, layered architecture, sub‑agent roles, schemas, Claude system prompt, job template, integration plan, implementation notes, and Mermaid/PlantUML diagrams to paste into docs.
