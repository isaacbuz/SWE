# Cost Model & Budgets

Pricing tables and max-per-run caps; prefer OSS coders for bulk edits; delegate long-context planning to cost-effective models where feasible; auto-downgrade near caps.
