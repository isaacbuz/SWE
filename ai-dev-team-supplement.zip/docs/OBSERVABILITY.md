# Observability & Policy

OpenTelemetry tracing for model/tool calls and MoE routing; redacted structured logs; metrics for token spend, latency, pass/fail; provider budgets; secret management; policy enforcement.
