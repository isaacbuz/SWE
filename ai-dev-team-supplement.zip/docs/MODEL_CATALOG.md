# Model Catalog (2025)

Closed: GPT‑5, Claude 4.x/Sonnet, Gemini 2.5 Pro/Flash, Grok 4.
Open: Qwen2.5‑Coder‑32B, Llama 3.1 405B, DeepSeek V3/R1, IBM Granite (Code 8B, 3.0/4.0 H‑Small, Nano).
