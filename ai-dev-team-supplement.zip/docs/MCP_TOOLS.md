# MCP Tool Chest

**github.mcp** — repos, issues, PRs, labels, projects, discussions
**tests.mcp** — run tests; return structured failures
**security.mcp** — SAST, secret scan, dep audit
**docs.mcp** — render Mermaid/PlantUML; update README/ADR/Wiki
**deploy.mcp** — Vercel/Netlify/Fly.io/K8s; preview links
