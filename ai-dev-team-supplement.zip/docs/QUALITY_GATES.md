# Quality Gates

Static analysis, tests (unit ≥80% coverage), security (OWASP, secrets, deps), style, complexity, performance budgets.
Failure → targeted patch loop before PR is merged.
