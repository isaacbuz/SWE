# GitHub Integration (Platform-first)

- Issues/Projects/PRs/Actions/Wiki/Discussions/Releases.
- Branch protection, PR templates, required checks.
- Labels: `ai-generated`, `ready-for-review`, `security`.
- Actions: `lint.yml`, `test.yml`, `security.yml`, `deploy.yml`, `release.yml`.
