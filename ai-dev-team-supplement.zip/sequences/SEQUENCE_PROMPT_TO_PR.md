# Prompt → PR
Prompt → Decompose → MoE route → Consensus → Generate → Quality → GitHub Actions → PR (with artifacts, links, ADRs).
