# Failing Tests → Targeted Patch
Failing trace → isolate scope → OSS coder + Architect minimal patch → re-test → update PR.
