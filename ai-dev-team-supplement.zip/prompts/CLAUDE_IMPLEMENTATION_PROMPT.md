# Claude Implementation Prompt

Implement the orchestrator + MoE + quality loop + MCP tool bindings.
Follow `/docs/*` and include Granite models as OSS coders/verifiers.
Create Actions workflows, ADRs, and a single PR that links issues and artifacts.
